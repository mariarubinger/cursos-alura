import React from 'react';

export default function PudimComBatata() {
  return (
    <div>
      Página de quiz
    </div>
  );
}
