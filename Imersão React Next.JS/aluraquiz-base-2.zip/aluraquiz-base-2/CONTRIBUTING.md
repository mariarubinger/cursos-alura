# Como adicionar meu projeto na vitrine?

> [Link da Vitrine](https://aluraquiz-base.alura-challenges.vercel.app/contribuidores)

- Faça um fork desse projeto
- Crie um arquivo .txt dentro da pasta `contributors`
   - A primeira linha deve ser seu usuário do github, e a segunda a URL do seu projeto publicado na Vercel
> Arquivo de exemplo: https://github.com/alura-challenges/aluraquiz-base/tree/main/contributors
- Abra um Pull Request e espere ele ser aprovado :)

> [Video tutorial](https://youtu.be/SE3pYKYFcZU)
